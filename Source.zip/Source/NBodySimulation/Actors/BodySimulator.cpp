﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "BodySimulator.h"

#include "Camera/CameraComponent.h"
#include "Components/InstancedStaticMeshComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetMathLibrary.h"

constexpr float MAX_TICK = 0.0167; // to have stable simulation steps

// Sets default values
ABodySimulator::ABodySimulator()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bStartWithTickEnabled = true;
	PrimaryActorTick.TickGroup = TG_DuringPhysics;
	InstancedMesh = CreateDefaultSubobject<UInstancedStaticMeshComponent>(TEXT("InstancedMesh"));
	SetRootComponent(InstancedMesh);
	// Setup the simulations viewport
	CameraArm = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraArmComponent"));
	CameraArm->SetRelativeLocationAndRotation(FVector(0.0f, 0.0f, 0.0f), FRotator(-90.0f, 0.0f, 0.0f));
	CameraArm->bDoCollisionTest = false;

	Camera = CreateDefaultSubobject<UCameraComponent>(TEXT("CameraComponent"));
	Camera->SetupAttachment(CameraArm, USpringArmComponent::SocketName);
	Camera->SetProjectionMode(ECameraProjectionMode::Orthographic);
	Camera->SetOrthoWidth(5000);

	AutoPossessPlayer = EAutoReceiveInput::Player0;
}

void ABodySimulator::BeginPlay()
{
	Super::BeginPlay();
	if (GEngine && GEngine->GameViewport)
	{
		GEngine->GameViewport->Viewport->ViewportResizedEvent.AddUObject(this, &ThisClass::OnViewportResized);
	}

	InitBodies();
}

void ABodySimulator::GetCameraValues()
{
	const APlayerController* PlayerController = Cast<APlayerController>(GetController());
	FVector WorldDir;

	FVector2D ViewportSize = FVector2D(1, 1);

	GEngine->GameViewport->GetViewportSize(/*out*/ViewportSize);

	UGameplayStatics::DeprojectScreenToWorld(PlayerController, FVector2D::Zero(), TopLeftBounds, WorldDir);
	TopLeftBounds += WorldDir * CameraArm->TargetArmLength;
	TopLeftBounds.Z = 0;

	UGameplayStatics::DeprojectScreenToWorld(PlayerController, ViewportSize, BottomRightBounds, WorldDir);
	BottomRightBounds += WorldDir * CameraArm->TargetArmLength;
	BottomRightBounds.Z = 0;

	bCameraViewportReady = true;
}


// Called when the game starts or when spawned
void ABodySimulator::InitBodies()
{
	Bodies.SetNumUninitialized(BodyNum);
	Transforms.SetNumUninitialized(BodyNum);
	for (int32 Index = 0; Index < BodyNum; ++Index)
	{
		FVector2D RandomPosition(FMath::RandPointInCircle(PlacementRadius));
		const float RadialSpeedFactor = PlacementRadius / RandomPosition.Size();
		const FVector RandomVelocity = UKismetMathLibrary::RandomUnitVector() * BaseInitialSpeed * RadialSpeedFactor;
		const float Mass = FMath::FRandRange(MinMass, MaxMass);
		const float MeshScale = FMath::Sqrt(Mass) * BodyDisplayScale;

		const FTransform MeshTransform(
			FRotator(),
			ConvertFVector2Dto3D(RandomPosition),
			FVector(MeshScale, MeshScale, 1.0f)
		);

		Transforms[Index] = MeshTransform;
		Bodies[Index] = FBodyEntity{RandomPosition, FVector2D(RandomVelocity.X, RandomVelocity.Y), Mass, Index};
	}
	InstancedMesh->AddInstances(Transforms, false, true);
}


void ABodySimulator::GravityStep(const float DeltaTime)
{
	ParallelFor(Bodies.Num(), [&](const int32 Index)
	{
		FVector2D Acceleration(0.0f, 0.0f);
		for (const FBodyEntity& AffectingBody : Bodies)
		{
			if (AffectingBody.Index == Bodies[Index].Index)
			{
				continue; // exclude self
			}
			float Distance = FVector2D::Distance(Bodies[Index].Position, AffectingBody.Position);
			Distance = FMath::Max(Distance, MinimumGravityDistance); // avoids division by zero
			Acceleration += AffectingBody.Mass / Distance * G / Distance * (AffectingBody.Position - Bodies[Index].Position) / Distance;
		}
		Bodies[Index].Velocity += Acceleration * DeltaTime;
	});
}


void ABodySimulator::UpdatePositionStep(const float DeltaTime)
{
	for (FBodyEntity& Body : Bodies)
	{
		AdjustPosition(Body.Position);
		Body.Position += Body.Velocity * DeltaTime;

		Transforms[Body.Index].SetTranslation(ConvertFVector2Dto3D(Body.Position));
	}

	InstancedMesh->BatchUpdateInstancesTransforms(0, Transforms, true, true);
}

void ABodySimulator::Tick(float DeltaTime)
{
	if (DeltaTime > MAX_TICK)
	{
		DeltaTime = MAX_TICK;
	}
	Super::Tick(DeltaTime);
	if (IsGravityEnabled)
	{
		GravityStep(DeltaTime);
	}
	UpdatePositionStep(DeltaTime);
}


void ABodySimulator::AdjustPosition(FVector2D& InPosition) const
{
	if (!bCameraViewportReady)
	{
		return;
	}
	if (InPosition.X > BottomRightBounds.Y)
	{
		InPosition.X = TopLeftBounds.Y;
	}
	else if (InPosition.X < TopLeftBounds.Y)
	{
		InPosition.X = BottomRightBounds.Y;
	}
	if (InPosition.Y > TopLeftBounds.X)
	{
		InPosition.Y = BottomRightBounds.X;
	}
	else if (InPosition.Y < BottomRightBounds.X)
	{
		InPosition.Y = TopLeftBounds.X;
	}
}

FVector ABodySimulator::ConvertFVector2Dto3D(const FVector2D& XYCoordinates)
{
	return FVector(XYCoordinates.Y, XYCoordinates.X, 0.0f);
}

void ABodySimulator::OnViewportResized(FViewport* Viewport, unsigned I)
{
	GetCameraValues();
}