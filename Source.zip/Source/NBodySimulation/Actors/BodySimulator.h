﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "BodySimulator.generated.h"


class UCameraComponent;
class USpringArmComponent;

USTRUCT()
struct FBodyEntity
{
	GENERATED_BODY()

	UPROPERTY()
	FVector2D Position;
	UPROPERTY()
	FVector2D Velocity;
	UPROPERTY()
	float Mass = 1.0f;
	UPROPERTY()
	int32 Index;
};


UCLASS()
class NBODYSIMULATION_API ABodySimulator : public APawn
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	ABodySimulator();

	UFUNCTION(BlueprintCallable)
	virtual void GetCameraValues();
	virtual void InitBodies();
	virtual void GravityStep(float DeltaTime);
	virtual void UpdatePositionStep(float DeltaTime);
	virtual void AdjustPosition(FVector2D& InPosition) const;
 	virtual FVector ConvertFVector2Dto3D(const FVector2D& XYCoordinates);

protected:
	virtual void OnViewportResized(FViewport* Viewport, unsigned I);
	virtual void BeginPlay() override;

public:
	virtual void Tick(float DeltaTime) override;
	// - COMPONENTS
public:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Instanced, NoClear)
	UInstancedStaticMeshComponent* InstancedMesh;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	USpringArmComponent* CameraArm;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	UCameraComponent* Camera;

	UPROPERTY(EditAnywhere, Category = "NBody Simulation Parameters")
	bool IsGravityEnabled = true;
	UPROPERTY(EditAnywhere, Category = "NBody Simulation Parameters")
	int BodyNum = 2500;
	UPROPERTY(EditAnywhere, Category = "NBody Simulation Parameters")
	float PlacementRadius = 1000.0f;
	UPROPERTY(EditAnywhere, Category = "NBody Simulation Parameters")
	float BaseInitialSpeed = 500.0f;

	////	UPROPERTY(EditAnywhere, Category = "NBody Simulation Parameters")
	//	FVector2D //InitialVelocity = FVector2D(1, 0);

	UPROPERTY(EditAnywhere, Category = "NBody Simulation Parameters")
	float BodyDisplayScale = 0.02f;
	UPROPERTY(EditAnywhere, Category = "NBody Simulation Parameters")
	float G = 1000.0f;
	UPROPERTY(EditAnywhere, Category = "NBody Simulation Parameters")
	float MinMass = 20.0f;
	UPROPERTY(EditAnywhere, Category = "NBody Simulation Parameters")
	float MaxMass = 100.0f;
	UPROPERTY(EditAnywhere, Category = "NBody Simulation Parameters")
	float MinimumGravityDistance = 100.0f; // prevents division by zero and forces too high

	UPROPERTY(BlueprintReadOnly)
	FVector TopLeftBounds;

	UPROPERTY(BlueprintReadOnly)
	FVector BottomRightBounds;

private:
	UPROPERTY()
	bool bCameraViewportReady;
	UPROPERTY()
	TArray<FBodyEntity> Bodies;
	UPROPERTY()
	TArray<FTransform> Transforms;
};